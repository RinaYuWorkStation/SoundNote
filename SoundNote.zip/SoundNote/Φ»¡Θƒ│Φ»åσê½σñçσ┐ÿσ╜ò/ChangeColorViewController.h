////

///planning to do a change color page


////  ChangeColorViewController.h
////  SoundNote
////
////  Created by yujiaqi on 5/12/17.
////  Copyright © 2017 yujiaqi. All rights reserved.
////
//
//#import <UIKit/UIKit.h>
//
//@interface ChangeColorViewController : UIViewController
//@property (nonatomic, assign) NSInteger RedInt;
//@property (nonatomic, assign) NSInteger GreenInt;
//@property (nonatomic, assign) NSInteger BlueInt;
//
//
//@end
