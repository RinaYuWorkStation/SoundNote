
#import <UIKit/UIKit.h>

@interface CollectViewController : UIViewController

@end
