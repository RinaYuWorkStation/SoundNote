
#import <UIKit/UIKit.h>

@interface CollectionViewCell : UICollectionViewCell

@property (weak, nonatomic) IBOutlet UIImageView *btnIcon;


@property (weak, nonatomic) IBOutlet UILabel *label;

@end
