
#import <UIKit/UIKit.h>

@interface UIImage (ResizImage)
+ (UIImage *)resizeWithImageName:(NSString *)name;

@end
