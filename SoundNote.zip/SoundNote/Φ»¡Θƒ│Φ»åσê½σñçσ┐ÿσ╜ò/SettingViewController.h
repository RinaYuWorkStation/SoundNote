
#import <UIKit/UIKit.h>

@interface SettingViewController : UITableViewController

@end
