
#import <UIKit/UIKit.h>

@interface EditProfileViewController : UITableViewController

@property(nonatomic,strong)UITableViewCell *cell;
@end
