
#import <UIKit/UIKit.h>

@interface UIColor (Hash)
+(UIColor *)colorFromHexString:(NSString *)hexString;
@end
