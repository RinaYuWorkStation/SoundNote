
#import <UIKit/UIKit.h>

@interface CollectionViewController : UICollectionViewController

@end
