
#import <UIKit/UIKit.h>

@interface WallpaperViewController : UIViewController

@end
