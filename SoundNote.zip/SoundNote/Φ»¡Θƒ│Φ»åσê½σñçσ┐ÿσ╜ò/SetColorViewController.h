
#import <UIKit/UIKit.h>

@interface SetColorViewController : UINavigationController
+(void)setupNavTheme;
@end
