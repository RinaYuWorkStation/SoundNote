
#define bScreenWidth [[UIScreen mainScreen] bounds].size.width

#define bNormalH 44

#define bIconW 50

#define bIconH 50

#define bBtnFont [UIFont systemFontOfSize:15.0f]

#define bBtnPadding 20
